CREATE STREAM order_stream (
    oder_id INT,
    product_name VARCHAR,
    order_domisili VARCHAR,
    order_qty INT,
    order_date DATE,
    new BOOLEAN
) WITH (
    KAFKA_TOPIC = 'assignment_day24',
    VALUE_FORMAT = 'JSON'
);