CREATE STREAM order_sum_stream AS
SELECT product_name, order_sum FROM aorder_sum_table EMIT CHANGES;

CREATE STREAM order_sum_exported WITH (
    KAFKA_TOPIC='order_sum_topic',
    VALUE_FORMAT='JSON'
) AS
SELECT * FROM order_sum_stream;
