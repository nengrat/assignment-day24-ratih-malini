CREATE TABLE order_table AS
SELECT order_id,
       LATEST_BY_OFFSET(product_name) AS product_name,
       LATEST_BY_OFFSET(order_domisili) AS order_domisili,
       LATEST_BY_OFFSET(order_qty) AS order_qty,
       LATEST_BY_OFFSET(order_date) AS order_date,
       LATEST_BY_OFFSET(new) AS new
FROM order_stream
GROUP BY order_id;
