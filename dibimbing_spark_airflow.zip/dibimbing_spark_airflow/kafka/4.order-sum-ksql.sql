CREATE TABLE order_sum_table AS
SELECT
    product_name,
    SUM(order_qty) AS order_sum
FROM order_stream
GROUP BY product_name
EMIT CHANGES;