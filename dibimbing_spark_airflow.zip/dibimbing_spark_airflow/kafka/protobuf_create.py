import order_pb2
from faker import Faker
import json
from datetime import datetime
faker = Faker()


class DataGenerator(object):
    @staticmethod
    def get_data():
        return [
                faker.random_int(min=1000000, max=9000000),
                faker.random_element(elements=('Sabun Mandi', 'Shampo', 'Kasur', 'Tas', 'Sepatu', 'TV', 'Lemari')),
                faker.random_element(elements=('Jakarta', 'Tangerang', 'Bogor', 'Banten', 'Depok', 'Bandung')),
                faker.random_int(min=10, max=500),
                faker.date_time_between(start_date=datetime(2000,1,1), end_date=datetime.now()).strftime('%Y-%m-%d %H:%M:%S')
        ]



data_list = DataGenerator.get_data()

# Create Protobuf message
order = order_pb2.Order(
    order_id=data_list[0],
    product_name=data_list[1],
    order_domisili=data_list[2],
    order_qty=data_list[3],
    order_date=data_list[4],
    new=True,
)
protobuf_data = order.SerializeToString()
with open("kafka/order_data.protobuf", "wb") as f:
    f.write(protobuf_data)


# Create JSON data
json_data = {
    "order_id": data_list[0],
    "product_name": data_list[1],
    "order_domisili": data_list[2],
    "order_qty": data_list[3],
    "order_date": data_list[4],
    "new": True,
}

json_str = json.dumps(json_data)
with open("kafka/order_data.json", "w") as f:
    f.write(json_str)
